use std::ffi::c_void;

/// AIC 真卡 PMm 特征值
const TARGET_PMM: [u8; 8] = [0x00, 0xF1, 0x00, 0x00, 0x00, 0x01, 0x43, 0x00];

/// 全 FF 占位 PMm（系统默认发出的）
const EMPTY_PMM: [u8; 8] = [0xFF; 8];

/// SENSF_RES_SETTING 命令头
const SENSF_CMD_HEADER: [u8; 2] = [0x51, 0x08];

/// C 侧调用的入口：在 p_param_tlvs 数据中查找并替换 PMm
///
/// # Safety
/// 由 C bridge 调用，ptr 和 len 由调用方保证有效
#[no_mangle]
pub unsafe extern "C" fn pmm_patch_params(ptr: *mut u8, len: usize) -> bool {
    if ptr.is_null() || len < 8 {
        return false;
    }

    let buf: &mut [u8] = unsafe { std::slice::from_raw_parts_mut(ptr, len) };
    let mut patched = false;

    // 滑动窗口扫描
    let scan_len = if len >= 8 { len - 7 } else { 0 };
    let mut i = 0;
    while i < scan_len {
        let window = &buf[i..i + 8];

        // 特征1：51 08 命令头，PMm 在后8字节
        if window[..2] == SENSF_CMD_HEADER && i + 10 <= len {
            let pmm_slice = &mut buf[i + 2..i + 10];
            if pmm_slice != TARGET_PMM {
                pmm_slice.copy_from_slice(&TARGET_PMM);
                android_log("PMm patched via SENSF_CMD_HEADER");
                patched = true;
            }
            i += 10;
            continue;
        }

        // 特征2：全 FF 的8字节 PMm 占位符
        if window == EMPTY_PMM {
            buf[i..i + 8].copy_from_slice(&TARGET_PMM);
            android_log("PMm patched via EMPTY_PMM");
            patched = true;
            i += 8;
            continue;
        }

        i += 1;
    }

    patched
}

/// 简易 Android log（通过 extern 链接 liblog）
fn android_log(msg: &str) {
    extern "C" {
        fn __android_log_write(prio: i32, tag: *const u8, text: *const u8) -> i32;
    }
    let tag  = b"KonamikU_pmm\0";
    let mut text = msg.as_bytes().to_vec();
    text.push(0);
    unsafe {
        __android_log_write(4, tag.as_ptr(), text.as_ptr());
    }
}