#include <jni.h>
#include <string.h>
#include <dlfcn.h>
#include <android/log.h>
#include "Dobby/include/dobby.h"
#include <sys/system_properties.h>

#define TAG "KonamikU_pmm"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// Rust 侧函数声明
extern int pmm_patch_params(uint8_t* ptr, size_t len);

// 原函数指针
static void (*orig_nfa_dm_check_set_config)(
    uint8_t num_param,
    uint8_t* p_param_tlvs,
    uint8_t* p_cur_params
) = NULL;

// hook 替换函数
static void hooked_nfa_dm_check_set_config(
    uint8_t num_param,
    uint8_t* p_param_tlvs,
    uint8_t* p_cur_params
) {
    if (p_param_tlvs != NULL && num_param > 0) {
        // 交给 Rust 处理 PMm 查找替换
        int patched = pmm_patch_params(p_param_tlvs, (size_t)num_param);
        if (patched) {
            LOGI("PMm patch applied");
        }
    }

    // 调用原函数
    if (orig_nfa_dm_check_set_config) {
        orig_nfa_dm_check_set_config(num_param, p_param_tlvs, p_cur_params);
    }
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("pmmtool loading...");

    void* handle = dlopen("libnfc-nci.so", RTLD_NOW);
    if (!handle) {
        LOGI("Failed to open libnfc-nci.so: %s", dlerror());
        return JNI_VERSION_1_6;
    }

    void* target = dlsym(handle, "nfa_dm_check_set_config");
    if (!target) {
        LOGI("Symbol not found: nfa_dm_check_set_config");
        dlclose(handle);
        return JNI_VERSION_1_6;
    }

    int ret = DobbyHook(
        target,
        (void*)hooked_nfa_dm_check_set_config,
        (void**)&orig_nfa_dm_check_set_config
    );

    if (ret == 0) {
        LOGI("Hook OK");
        // 通知 App 侧 pmmtool 已激活
        __system_property_set("debug.konamiku.pmmtool", "1");
    } else {
        LOGI("Hook failed: %d", ret);
    }

    dlclose(handle);
    return JNI_VERSION_1_6;
}